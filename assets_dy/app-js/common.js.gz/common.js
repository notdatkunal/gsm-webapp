// document.addEventListener("DOMContentLoaded", () => {
//     const studentForm = document.getElementById("userForm");
//     document.body.addEventListener("click", (e) => {
//         const target = e.target;
//         if (target.classList.contains("studentCloseForm")) {
//             closeStudentForm(e);
//         } else if (target.classList.contains("studentAddForm")) {
//             showStudentForm(e);
//         }
//     });
   
//     function closeStudentForm(e) {
//         e.preventDefault();
//         studentForm.style.display = "none";
//     }
 
//     function showStudentForm(e) {
//         e.preventDefault();
//         studentForm.style.display = "block";
//     }
// });




